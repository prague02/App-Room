package br.edu.fatecpg.approom.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import br.edu.fatecpg.approom.model.User

@Dao
interface UserDao {
    @Query("SELECT * FROM user")
    fun getAll(): List<User>

    @Insert
    suspend fun insertAll(vararg user: User)

    @Query("DELETE FROM user WHERE id = :userId")
    suspend fun deleteById(userId: Int)
}
