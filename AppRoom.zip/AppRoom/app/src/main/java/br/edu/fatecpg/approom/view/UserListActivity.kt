package br.edu.fatecpg.approom.view

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import br.edu.fatecpg.approom.UserAdapter
import br.edu.fatecpg.approom.dao.UserDao
import br.edu.fatecpg.approom.databinding.ActivityUserListBinding
import br.edu.fatecpg.approom.db.AppDatabase
import br.edu.fatecpg.approom.model.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UserListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserListBinding
    private lateinit var dao: UserDao
    private lateinit var adapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "db-users"
        ).build()
        dao = db.userDao()

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = UserAdapter(mutableListOf(), ::onDeleteClick)
        binding.recyclerView.adapter = adapter

        carregarUsuarios()
    }

    private fun carregarUsuarios() {
        lifecycleScope.launch {
            val users = withContext(Dispatchers.IO) { dao.getAll() }
            adapter.updateList(users)
        }
    }

    private fun onDeleteClick(user: User) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { dao.deleteById(user.id) }
            Toast.makeText(this@UserListActivity, "Usuário excluído!", Toast.LENGTH_SHORT).show()
            carregarUsuarios()
        }
    }
}
