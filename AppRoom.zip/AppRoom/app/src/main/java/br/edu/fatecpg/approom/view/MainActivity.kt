package br.edu.fatecpg.approom.view

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import br.edu.fatecpg.approom.dao.UserDao
import br.edu.fatecpg.approom.databinding.ActivityMainBinding
import br.edu.fatecpg.approom.db.AppDatabase
import br.edu.fatecpg.approom.model.User
import kotlinx.coroutines.launch
import br.edu.fatecpg.approom.R


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: AppDatabase
    private lateinit var dao: UserDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "db-users"
        ).build()

        dao = db.userDao()

        binding.btnSave.setOnClickListener {
            val firstName = binding.edtFirstName.text.toString().trim()
            val lastName = binding.edtLastName.text.toString().trim()

            if (firstName.isEmpty() || lastName.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val user = User(0, firstName, lastName)

            lifecycleScope.launch {
                dao.insertAll(user)
                runOnUiThread {
                    Toast.makeText(applicationContext, "Cadastro realizado!", Toast.LENGTH_SHORT).show()
                    binding.edtFirstName.text.clear()
                    binding.edtLastName.text.clear()
                }
            }
        }

        binding.btnList.setOnClickListener {
            val intent = Intent(this, UserListActivity::class.java)
            startActivity(intent)
        }
    }
}
